---
title: "Insecure Direct Object References (IDOR): Obfuscating Database Primary Keys using AES-GCM"
description: "In insecure web applications, resources are frequently identified by their internal database primary keys, which are often sequential integers (e.g., `1001`, `1002`). When these keys are exposed direc"
type: "ARTICLE"
categorySlug: "appsec-threats"
articleType: "GUIDE"
---

# Insecure Direct Object References (IDOR): Obfuscating Database Primary Keys using AES-GCM

## The Problem: Predictable Resource Handles

In insecure web applications, resources are frequently identified by their internal database primary keys, which are often sequential integers (e.g., `1001`, `1002`). When these keys are exposed directly in URL paths, query parameters, or API payloads, a vulnerability known as Insecure Direct Object Reference (IDOR) is introduced.

An IDOR vulnerability occurs when an attacker can access arbitrary records simply by modifying the resource identifier (e.g., changing `/api/v1/invoices/1001` to `/api/v1/invoices/1002`). While the absolute first line of defense is backend authorization checks (verifying that the logged-in user owns the requested resource), a powerful defense-in-depth practice is to prevent the exposure of internal database structures entirely. Revealing sequential integers leaks business metrics (such as daily volume) and makes mass scraping and crawling trivial. Obfuscating these identifiers with cryptographically secure, authenticated tokens completely neutralizes sequential prediction attacks.

## Architectural Flaw: Exposing Autoincrementing Integers

Exposing raw integer IDs allows adversaries to map the database structure and automate data scraping engines.

```text
Vulnerable Sequential Exposure:
[ Database: User Table ] ---> ID: 101, Name: Alice ---> Served as: /api/profile?id=101
[ Attacker ] ---> Crawls sequentially: id=102, id=103, id=104... ---> Recovers all users

Secure Cryptographic Obfuscation (AES-GCM):
[ Database: User Table ] ---> ID: 101 ---> Encrypted via AES-256-GCM ---> Token: "gcm-3af89c..."
[ Attacker ] ---> Tries to guess next token ---> Modifies "gcm-3af89c..." to "gcm-3af89d..."
                                                    |
                                                    v
                                      [ Decryption & Auth Check ] ---> Fails Integrity check! (Throws 403)
```

Simply hashing the ID (e.g., using MD5 or SHA-256) is insufficient. Plain hashes are deterministic; an attacker can pre-compute hashes of sequential numbers (MD5 of 1, 2, 3...) to map them back to the original IDs. Instead, applications require Authenticated Encryption.

## Exploit Mechanics: Scraping and Brute-force Crawling

In a standard IDOR attack, an adversary observes their own account request:
`GET /api/v1/billing/statement?id=48209`

They construct a high-frequency script that iterates the `id` parameter down to `1`:
`for i in {48209..1}; do curl -H "Authorization: Bearer Token" "/api/v1/billing/statement?id=$i"; done`

If any statement executes without matching the authorization context of the user, the server leaks sensitive transaction files.

## The Solution: AES-GCM Tokenization

To safely conceal internal integer IDs while ensuring the client cannot forge or tamper with the reference, developers can utilize **AES-256-GCM** (Advanced Encryption Standard in Galois/Counter Mode). 

### Why AES-GCM?
*   **Symmetric Encryption:** Conceals the internal database ID, converting it into an unguessable high-entropy string.
*   **Authentication (AEAD):** AES-GCM appends a 16-byte authentication tag to the cipher text. During decryption, the system verifies this tag. If an attacker modifies even a single bit of the token (e.g., flipping a bit to guess a different ID), the decryption algorithm fails fast, throwing an exception before the database is queried.
*   **Initialization Vector (IV):** A unique IV is generated for every encryption pass, ensuring that encrypting the same ID twice produces completely different tokens.

## Robust Implementation in Node.js

Below is a production-grade utility demonstrating how to encrypt and decrypt database primary keys using AES-256-GCM:

```javascript
// IdObfuscator.js
const crypto = require('crypto');

// 256-bit Key stored in environment variables
const ENCRYPTION_KEY = process.env.ID_ENCRYPTION_KEY 
    ? Buffer.from(process.env.ID_ENCRYPTION_KEY, 'hex')
    : crypto.randomBytes(32); // Fallback for demonstration, do not use in production!

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12;      // Standard IV size for GCM
const TAG_LENGTH = 16;     // Standard Auth Tag size for GCM

class IdObfuscator {

    /**
     * Encrypts an integer database ID into a safe URL-friendly string.
     */
    static encryptId(rawId) {
        if (typeof rawId !== 'number' && typeof rawId !== 'string') {
            throw new Error('ID must be a number or string');
        }

        const plainText = String(rawId);
        const iv = crypto.randomBytes(IV_LENGTH);
        const cipher = crypto.createCipheriv(ALGORITHM, ENCRYPTION_KEY, iv);

        let encrypted = cipher.update(plainText, 'utf8', 'hex');
        encrypted += cipher.final('hex');

        // Extract the authentication tag generated by GCM
        const authTag = cipher.getAuthTag();

        // Construct token: IV (hex) + AuthTag (hex) + Ciphertext (hex)
        const token = `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
        
        // Convert to Base64url to ensure safety in query strings and paths
        return Buffer.from(token).toString('base64url');
    }

    /**
     * Decrypts a token back into the original ID.
     * Throws an error if the token has been tampered with.
     */
    static decryptId(token) {
        try {
            // Restore standard string format from base64url
            const rawToken = Buffer.from(token, 'base64url').toString('utf8');
            const [ivHex, tagHex, encryptedHex] = rawToken.split(':');

            if (!ivHex || !tagHex || !encryptedHex) {
                throw new Error('Invalid token structure');
            }

            const iv = Buffer.from(ivHex, 'hex');
            const tag = Buffer.from(tagHex, 'hex');
            const encryptedText = Buffer.from(encryptedHex, 'hex');

            const decipher = crypto.createDecipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
            decipher.setAuthTag(tag);

            let decrypted = decipher.update(encryptedText, 'binary', 'utf8');
            decrypted += decipher.final('utf8');

            // Return original representation (as integer if applicable)
            return isNaN(decrypted) ? decrypted : parseInt(decrypted, 10);

        } catch (error) {
            // Decryption failure indicates key tampering or corrupt token
            throw new SecurityException('Unauthorized ID Modification: Token Integrity Check Failed.');
        }
    }
}

class SecurityException extends Error {
    constructor(message) {
        super(message);
        this.name = "SecurityException";
    }
}

module.exports = IdObfuscator;
```

### Clean Route Handler Integration

```javascript
const IdObfuscator = require('./IdObfuscator');
const express = require('express');
const router = express.Router();

router.get('/api/v1/invoices/:obfuscatedId', async (req, res) => {
    try {
        // 1. Decrypt the obfuscated route parameter
        const originalInvoiceId = IdObfuscator.decryptId(req.params.obfuscatedId);
        
        // originalInvoiceId is now safely recovered as an integer, e.g., 1001

        // 2. Query DB and run standard context-ownership validation
        const invoice = await mockDatabaseQueryInvoice(originalInvoiceId);
        if (!invoice) {
            return res.status(404).json({ error: 'Invoice not found.' });
        }

        // Verify ownership (Absolute Authorization Requirement)
        if (invoice.ownerId !== req.user.id) {
            return res.status(403).json({ error: 'Access Denied.' });
        }

        return res.status(200).json(invoice);

    } catch (err) {
        // Log cryptographic failures for monitoring
        console.error(`Attack attempt or corrupted token: ${err.message}`);
        return res.status(400).json({ error: 'Invalid identifier.' });
    }
});

async function mockDatabaseQueryInvoice(id) {
    if (id === 1001) {
        return { id: 1001, amount: 250.00, ownerId: 'usr_abc123' };
    }
    return null;
}
```

## Conclusion

Exposing predictable database primary keys leaves web applications vulnerable to brute-force IDOR campaigns and resource scraping. While server-side authorization check middleware is always mandatory, encrypting these identifiers with AES-256-GCM introduces strong defense-in-depth. Because GCM incorporates cryptographic message authentication, any attempt by an attacker to manipulate token payloads is intercepted at the decryption gateway, preventing unauthorized resource queries before they ever touch the database layer.
